﻿//====================================================================================================
//The Free Edition of Java to C# Converter limits conversion output to 100 lines per snippet.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-java-to-csharp.html
//====================================================================================================

using System;
using System.Collections.Generic;

namespace com.revature.Servlets
{
	;

	======= import HashSet<object>;
	import System.Collections.IList;
	import System.Collections.IDictionary;
	import ISet<object>;

	>>>>(int)((uint) >> ed8a34de6d63eed36f000f5f175bbaa344e6102f) import javax.servlet.ServletConfig;
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;

	import org.apache.log4j.Logger;

	import com.google.gson.Gson;
	import com.revature.Connection.JDBCConnection;
	import com.revature.Database.EmpField;
	import com.revature.Database.EmployeeDataService;
	import com.revature.Database.ExpensesService;
	import com.revature.Database.LoginService;
	import com.revature.model.Approval;
	import com.revature.model.Employee;
	import com.revature.model.Expense;
	import com.revature.model.Position;
	import com.revature.util.JSONParser;


	public class FrontController extends HttpServlet
	{
		final static Logger log = Logger.getLogger(typeof(FrontController));
		private static final long serialVersionUID = 1L;

		private static LoginService loginService;
		private static EmployeeDataService employeeDataService;
		private static ExpensesService expensesService;
		private static HttpSession session;

		public FrontController()
		{
			base();
		}


		public void init(ServletConfig config) throws ServletException
		{
			log.info("FrontController Init");
			loginService = LoginService.getLoginService();
			employeeDataService = EmployeeDataService.getEmployeeDataService();
			expensesService = ExpensesService.getExpensesService();
		}

		public void destroy()
		{
			log.info("FrontController Destroy");
			try
			{
				JDBCConnection.getConnection().close();
			}
			catch (SQLException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
				log.error(e.Message);
			}
		}

		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
		{


			Console.WriteLine(request.getRequestURI());
			switch (request.getRequestURI())
			{

			case "/project1/logout.do":
				logout(request, response);
				break;
			}
		}

		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
		{

			Console.WriteLine(request.getRequestURI());
			switch (request.getRequestURI())
			{
			case "/project1/Project1/dist/html/login.do":
				handleLogin(request.getParameter("username"), request.getParameter("password"), request, response);
				break;
			case "/project1/Project1/dist/html/register.do":
				handleRegister(request, response);
				break;
			case "/project1/getEmployees.do":
				sendEmployeesToClient(response);
				break;
			case "/project1/getExpenses.do":
				sendExpensesToClient(response);
				break;
			case "/project1/getCurrentEmployee.do":
				getCurrentEmployee(response, request);
				break;
			case "/project1/getEmployeeId.do":
				getEmployeeId(response);
				break;
			case "/project1/create.do":
				createEmployee(request, response);
				break;
			case "/project1/submitExpenses.do":
				submitExpense(request, response);
				break;
			case "/project1/validateUsername.do":
				validateUserName(request, response);
				break;
			case "/project1/editemployee.do":
				editEmployee(request);
				break;
			case "/project1/resolveExpense.do":
				resolveExpense(request, response);
				break;
	<<<<<<< HEAD case "/project1/forgotusername.do": forgotUsername(request, response);
				break;
	======= >>>>(int)((uint) >> ed8a34de6d63eed36f000f5f175bbaa344e6102f)
break;
			}

		}

	<<<<<<< HEAD private void forgotUsername(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
			string data = request.getReader().readLine();
			Console.WriteLine(data);
			string username = null;
			IDictionary<string, string> emailData = JSONParser.parse(data);
			string employeeId = emailData["employeeId"];
			Employee employee = employeeDataService.getEmployeeById(employeeId);

//====================================================================================================
//End of the allowed output for the Free Edition of Java to C# Converter.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-java-to-csharp.html
//====================================================================================================

//Helper class added by Java to C# Converter:

//---------------------------------------------------------------------------------------------------------
//	Copyright © 2007 - 2022 Tangible Software Solutions, Inc.
//	This class can be used by anyone provided that the copyright notice remains intact.
//
//	This class is used to replace some calls to the java.lang.Math class.
//---------------------------------------------------------------------------------------------------------
using System;

internal static class MathHelper
{
	private static Random randomInstance = null;

	public static double NextDouble
	{
		get
		{
			if (randomInstance == null)
				randomInstance = new Random();

			return randomInstance.NextDouble();
		}
	}

	public static double Expm1(double x)
	{
		if (Math.Abs(x) < 1e-5)
			return x + 0.5 * x * x;
		else
			return Math.Exp(x) - 1.0;
	}

	public static double Log1p(double x)
	{
		double y = x;
		return ((1 + y) == 1) ? y : y * (Math.Log(1 + y) / ((1 + y) - 1));
	}
}