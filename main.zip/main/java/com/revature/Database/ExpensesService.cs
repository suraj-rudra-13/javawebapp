﻿using System.Collections.Generic;

namespace com.revature.Database
{

	using Logger = org.apache.log4j.Logger;

	using Approval = com.revature.model.Approval;
	using Employee = com.revature.model.Employee;
	using Expense = com.revature.model.Expense;

	public class ExpensesService
	{

		internal static readonly Logger log = Logger.getLogger(typeof(EmployeeDataService));
		private static ExpensesService instance;
		private ExpensesDAO expensesDao;

		private ExpensesService()
		{
			this.expensesDao = ExpensesDAO.getExpensesDAO();
		}

		public static ExpensesService ExpensesService
		{
			get
			{
				instance = instance == null ? new ExpensesService() : instance;
				return instance;
			}
		}

		public virtual void submitExpense(Expense expense)
		{
			this.expensesDao.submitExpense(expense);
		}

		public virtual Expense getExpense(Employee employee, Expense expense)
		{
			return this.expensesDao.getExpense(employee, expense);
		}

		public virtual IList<Expense> getAllRequestorsExpenses(Employee employee)
		{
			return this.expensesDao.getAllRequestorsExpenses(employee);
		}

		public virtual IList<Expense> AllExpenses
		{
			get
			{
				return this.expensesDao.getAllExpenses();
			}
		}

		public virtual void resolveExpense(int eid, Approval approval, string approvingManager)
		{
			this.expensesDao.resolveExpense(eid, approval, approvingManager);
		}

	}

}