﻿using System;
using System.Collections.Generic;

namespace com.revature.Database
{

	using Logger = org.apache.log4j.Logger;

	using JDBCConnection = com.revature.Connection.JDBCConnection;
	using Approval = com.revature.model.Approval;
	using Employee = com.revature.model.Employee;
	using Expense = com.revature.model.Expense;

	public class ExpensesDAO : ExpensesDAOInterface
	{
		internal static readonly Logger log = Logger.getLogger(typeof(ExpensesDAO));

		private static ExpensesDAO instance;

		private ExpensesDAO()
		{

		}

		public static ExpensesDAO ExpensesDAO
		{
			get
			{
				instance = instance == null ? new ExpensesDAO() : instance;
				return instance;
			}
		}

		public virtual void submitExpense(Expense expense)
		{
			try
			{
				string sql = "CALL add_expense(?,?,?,?,?,?,?)";

				Connection conn = JDBCConnection.getConnection();
				CallableStatement cs = conn.prepareCall(sql);
				cs.setString(1, expense.getProvider());
				cs.setString(2, expense.getDate());
				cs.setString(3, expense.getReason());
				cs.setDouble(4, expense.getAmount());
				cs.setInt(5, expense.getApproval().getApproval());
				cs.setInt(6, expense.getOwner().getUid());
				cs.setString(7, expense.getApprovingManager());

				cs.executeUpdate();

			}
			catch (SQLException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
				log.error(e.Message);
			}
		}

		public virtual Expense getExpense(Employee employee, Expense expense)
		{
			IList<Expense> expenses = this.getAllRequestorsExpenses(employee);
			foreach (Expense exp in expenses)
			{
				if (exp.getEid() == expense.getEid())
				{
					return exp;
				}
			}
			return null;
		}

		public virtual IList<Expense> getAllRequestorsExpenses(Employee employee)
		{
			try
			{
				string sql = "SELECT * FROM expense WHERE owner = ?";

				Connection conn = JDBCConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, employee.getUid());

				ResultSet rs = ps.executeQuery();

				IList<Expense> expenses = new List<Expense>();
				while (rs.next())
				{
					expenses.Add(new Expense(rs.getInt("e_id"), rs.getString("provider"), rs.getString("expense_date"), rs.getDouble("amount"), rs.getString("reason"), Approval.getApprovalLevel(rs.getInt("approval")), rs.getString("approvingmanager"), employee));
				}
				return expenses;

			}
			catch (SQLException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
				log.error(e.Message);
			}
			return null;
		}

		public virtual IList<Expense> AllExpenses
		{
			get
			{
				EmployeeDataService eds = EmployeeDataService.getEmployeeDataService();
				IList<Employee> employees = eds.getAllEmployees();
				IList<Expense> allExpenses = new List<Expense>();
    
				foreach (Employee employee in employees)
				{
					IList<Expense> expenses = this.getAllRequestorsExpenses(employee);
					if (expenses != null && expenses.Count != 0)
					{
						((List<Expense>)allExpenses).AddRange(expenses);
					}
				}
    
				return allExpenses;
			}
		}

		public virtual void resolveExpense(int eid, Approval approval, string approvingManager)
		{
			try
			{
				string sql = "UPDATE expense SET approval = ?, approvingmanager = ? WHERE e_id = ?";

				Connection conn = JDBCConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, approval.getApproval());
				ps.setString(2, approvingManager);
				ps.setInt(3, eid);

				ps.executeUpdate();

			}
			catch (SQLException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
				log.error(e.Message);
			}
		}

		public virtual void deleteExpense(Expense expense)
		{
			try
			{
				string sql = "DELETE FROM expense WHERE e_id = ?";

				Connection conn = JDBCConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1,expense.getEid());

				ps.executeUpdate();

			}
			catch (SQLException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
				log.error(e.Message);
			}
		}


	}

}