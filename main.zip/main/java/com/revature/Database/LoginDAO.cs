﻿//====================================================================================================
//The Free Edition of Java to C# Converter limits conversion output to 100 lines per snippet.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-java-to-csharp.html
//====================================================================================================

using System;
using System.Collections.Generic;

namespace com.revature.Database
{

	using Logger = org.apache.log4j.Logger;

	using JDBCConnection = com.revature.Connection.JDBCConnection;
	using LoginException = com.revature.exceptions.LoginException;
	using Employee = com.revature.model.Employee;
	using Position = com.revature.model.Position;

	public class LoginDAO : LoginDAOInterface
	{
		internal static readonly Logger log = Logger.getLogger(typeof(LoginDAO));

		private static LoginDAO instance;

		private LoginDAO()
		{

		}

		public static LoginDAO LoginDAO
		{
			get
			{
				instance = instance == null ? new LoginDAO() : instance;
				return instance;
			}
		}

		public virtual Employee getEmployeeByLogin(string username, string password)
		{
			try
			{
				string sql = "SELECT * FROM employees INNER JOIN login ON u_id = owner WHERE login.username = ? AND login.password = ?";

				Connection conn = JDBCConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, username);
				ps.setString(2, password);

				ResultSet rs = ps.executeQuery();

				while (rs.next())
				{
					return new Employee(rs.getInt("u_id"), rs.getString("fname"), rs.getString("lname"), rs.getString("employeeid"), Position.fromString(rs.getString("position")), rs.getString("street"), rs.getString("city"), rs.getString("state"), rs.getString("zip"), rs.getString("phone"), rs.getString("email"), rs.getInt("manager"));
				}

			}
			catch (SQLException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
				log.error(e.Message);
			}
			return null;
		}

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in C#:
//ORIGINAL LINE: public void setEmployeeLogin(com.revature.model.Employee employee, String username, String password) throws com.revature.exceptions.LoginException
		public virtual void setEmployeeLogin(Employee employee, string username, string password)
		{
			try
			{

				string sql = "CALL add_login(?,?,?)";

				IList<int> owners = this.AllLoginOwners;
				if (owners != null && owners.Contains(employee.getUid()))
				{
					throw new LoginException();
				}

				Connection conn = JDBCConnection.getConnection();
				CallableStatement cs = conn.prepareCall(sql);
				cs.setString(1, username);
				cs.setString(2, password);
				cs.setInt(3, employee.getUid());

				cs.executeUpdate();

			}
			catch (SQLException e)
			{
				log.error(e.Message);
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
			}
		}

		public virtual IList<string> AllUsernames
		{
			get
			{
				try
				{
					string sql = "SELECT username FROM login";
    
					Connection conn = JDBCConnection.getConnection();
					PreparedStatement ps = conn.prepareStatement(sql);
					ResultSet rs = ps.executeQuery();
    
					IList<string> usernames = new List<string>();
    
					while (rs.next())
					{
						usernames.Add(rs.getString("username"));
					}
    
					return usernames;
    
    
				}
				catch (SQLException e)
				{
					Console.WriteLine(e.ToString());
					Console.Write(e.StackTrace);
					log.error(e.Message);
				}
				return null;
			}
		}

		/// <summary>
		/// Returns a list of EmployeeIds for all employees with a log in
		/// Used to verify that the employee doesn't already have a log in
		/// before creating a new one.
		/// </summary>
		public virtual IList<int> AllLoginOwners
		{
			get
			{
				try
				{
					string sql = "Select owner FROM login";
    
					Connection conn = JDBCConnection.getConnection();
					PreparedStatement ps = conn.prepareStatement(sql);
					ResultSet rs = ps.executeQuery();
					IList<int> owners = new List<int>();
    
					while (rs.next())
					{
						owners.Add(rs.getInt("owner"));
					}
    
					return owners;
				}
				catch (SQLException e)
				{
					Console.WriteLine(e.ToString());
					Console.Write(e.StackTrace);
					log.error(e.Message);
				}
    
    
				return null;
			}
		}

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in C#:
//ORIGINAL LINE: public void updateEmployeeLogin(com.revature.model.Employee employee, LoginField field, String newVal) throws com.revature.exceptions.LoginException
		public virtual void updateEmployeeLogin(Employee employee, LoginField field, string newVal)
		{
			try
			{
				if (field.Equals(LoginField.USERNAME))
				{
					IList<string> usernames = this.AllUsernames;
					if (usernames.Contains(newVal))
					{
						throw new LoginException("Username is already taken!");
					}
				}


				string sql = string.Format("UPDATE login SET {0} = ? WHERE owner = ?", field.getField());

				Connection conn = JDBCConnection.getConnection();
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, newVal);
				ps.setInt(2, employee.getUid());

				ps.executeUpdate();

			}
			catch (SQLException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
				log.error(e.Message);
			}

		}

		public virtual void deleteEmployeeLogin(Employee employee)
		{
			try
			{

//====================================================================================================
//End of the allowed output for the Free Edition of Java to C# Converter.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-java-to-csharp.html
//====================================================================================================