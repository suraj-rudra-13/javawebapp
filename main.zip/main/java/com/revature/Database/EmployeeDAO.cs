﻿//====================================================================================================
//The Free Edition of Java to C# Converter limits conversion output to 100 lines per snippet.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-java-to-csharp.html
//====================================================================================================

using System;
using System.Collections.Generic;

namespace com.revature.Database
{

	using Logger = org.apache.log4j.Logger;


	using JDBCConnection = com.revature.Connection.JDBCConnection;
	using EmployeeException = com.revature.exceptions.EmployeeException;
	using Employee = com.revature.model.Employee;
	using Position = com.revature.model.Position;

	/// <summary>
	/// Data Access Object for Employee table
	/// @author jonathankuhl
	/// 
	/// </summary>
	public class EmployeeDAO : EmployeeDAOInterface
	{
		internal static readonly Logger log = Logger.getLogger(typeof(EmployeeDAO));

		private static EmployeeDAO instance;

		private EmployeeDAO()
		{

		}

		public static EmployeeDAO EmployeeDAO
		{
			get
			{
				instance = instance == null ? new EmployeeDAO() : instance;
				return instance;
			}
		}

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in C#:
//ORIGINAL LINE: public void createEmployee(com.revature.model.Employee employee) throws com.revature.exceptions.EmployeeException
		public virtual void createEmployee(Employee employee)
		{
			try
			{
				string sql = "CALL add_employee(?,?,?,?,?,?,?,?,?,?)";

				IList<string> employeeIds = this.EmployeeIds;
				if (employeeIds.Contains(employee.getEmployeeId()))
				{
					throw new EmployeeException();
				}

				Connection conn = JDBCConnection.getConnection();
				if (conn == null)
				{
					log.warn("Problem connectiong to Oracle");
					return;
				}
				CallableStatement cs = conn.prepareCall(sql);

				int i = 0;
				cs.setString(++i, employee.getFname());
				cs.setString(++i, employee.getLname());
				cs.setString(++i, employee.getPosition().getPosition());
				cs.setString(++i, employee.getEmployeeId());
				cs.setString(++i, employee.getStreet());
				cs.setString(++i, employee.getCity());
				cs.setString(++i, employee.getState());
				cs.setString(++i, employee.getZip());
				cs.setString(++i, employee.getPhone());
				cs.setString(++i, employee.getEmail());

				cs.executeUpdate();

			}
			catch (SQLException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
				log.error(e.InnerException);
				log.error(e.Message);
			}
		}

		public virtual IList<string> EmployeeIds
		{
			get
			{
				IList<Employee> employees = this.AllEmployees;
				if (employees == null)
				{
					log.warn("Null employees, check Oracle connection");
					return null;
				}
				IList<string> employeeIds = new List<string>();
    
				foreach (Employee emp in employees)
				{
					employeeIds.Add(emp.getEmployeeId());
				}
    
				return employeeIds;
			}
		}


		public virtual Employee getEmployeeById(int id)
		{
			try
			{
				string sql = string.Format("SELECT * FROM employees WHERE u_id = ?");

				Connection conn = JDBCConnection.getConnection();
				if (conn == null)
				{
					log.warn("Problem connectiong to Oracle");
					return null;
				}
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, id);

				ResultSet rs = ps.executeQuery();

				while (rs.next())
				{
					return new Employee(rs.getInt("u_id"), rs.getString("fname"), rs.getString("lname"), rs.getString("employeeid"), Position.fromString(rs.getString("position")), rs.getString("street"), rs.getString("city"), rs.getString("state"), rs.getString("zip"), rs.getString("phone"), rs.getString("email"), rs.getInt("manager"));
				}


			}
			catch (SQLException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
				log.error(e.InnerException);
				log.error(e.Message);
			}
			return null;
		}

		public virtual Employee getEmployeeByIdAndName(string employeeId, string fname, string lname)
		{
			try
			{
				string sql = string.Format("SELECT * FROM employees WHERE employeeId = ? AND fname = ? AND lname = ?");

				Connection conn = JDBCConnection.getConnection();
				if (conn == null)
				{
					log.warn("Problem connectiong to Oracle");
					return null;
				}
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setString(1, employeeId);
				ps.setString(2, fname);
				ps.setString(3, lname);

				ResultSet rs = ps.executeQuery();

				while (rs.next())
				{
					return new Employee(rs.getInt("u_id"), rs.getString("fname"), rs.getString("lname"), rs.getString("employeeid"), Position.fromString(rs.getString("position")), rs.getString("street"), rs.getString("city"), rs.getString("state"), rs.getString("zip"), rs.getString("phone"), rs.getString("email"), rs.getInt("manager"));
				}


			}
			catch (SQLException e)
			{
				Console.WriteLine(e.ToString());
				Console.Write(e.StackTrace);
				log.error(e.InnerException);
				log.error(e.Message);
			}

			return null;
		}

		public virtual Employee getEmployeeById(string employeeId)
		{
			try
			{
				string sql = string.Format("SELECT * FROM employees WHERE employeeId = ?");

				Connection conn = JDBCConnection.getConnection();
				if (conn == null)
				{
					log.warn("Problem connectiong to Oracle");

//====================================================================================================
//End of the allowed output for the Free Edition of Java to C# Converter.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-java-to-csharp.html
//====================================================================================================