﻿namespace com.revature.Database
{
	public class RecieptsDAO
	{

	}

}