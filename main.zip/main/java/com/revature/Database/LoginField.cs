﻿using System.Collections.Generic;

namespace com.revature.Database
{
	public sealed class LoginField
	{
		public static readonly LoginField USERNAME = new LoginField("USERNAME", InnerEnum.USERNAME, "username");
		public static readonly LoginField PASSWORD = new LoginField("PASSWORD", InnerEnum.PASSWORD, "password");

		private static readonly List<LoginField> valueList = new List<LoginField>();

		static LoginField()
		{
			valueList.Add(USERNAME);
			valueList.Add(PASSWORD);
		}

		public enum InnerEnum
		{
			USERNAME,
			PASSWORD
		}

		public readonly InnerEnum innerEnumValue;
		private readonly string nameValue;
		private readonly int ordinalValue;
		private static int nextOrdinal = 0;

		private string field;

		internal LoginField(string name, InnerEnum innerEnum, string field)
		{
			this.field = field;

			nameValue = name;
			ordinalValue = nextOrdinal++;
			innerEnumValue = innerEnum;
		}

		public string Field
		{
			get
			{
				return this.field;
			}
		}

		public static LoginField[] values()
		{
			return valueList.ToArray();
		}

		public int ordinal()
		{
			return ordinalValue;
		}

		public override string ToString()
		{
			return nameValue;
		}

		public static LoginField valueOf(string name)
		{
			foreach (LoginField enumInstance in LoginField.valueList)
			{
				if (enumInstance.nameValue == name)
				{
					return enumInstance;
				}
			}
			throw new System.ArgumentException(name);
		}
	}

}