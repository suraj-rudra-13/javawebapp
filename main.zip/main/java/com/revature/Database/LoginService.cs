﻿using System;
using System.Collections.Generic;

namespace com.revature.Database
{

	using Logger = org.apache.log4j.Logger;

	using LoginException = com.revature.exceptions.LoginException;
	using Employee = com.revature.model.Employee;

	public class LoginService
	{

		internal static readonly Logger log = Logger.getLogger(typeof(LoginService));

		private static LoginService instance;
		private LoginDAO loginDAO;

		private LoginService()
		{
			this.loginDAO = LoginDAO.getLoginDAO();
		}

		public static LoginService LoginService
		{
			get
			{
				instance = instance == null ? new LoginService() : instance;
				return instance;
			}
		}

		public virtual Employee getEmployeeByLogin(string username, string password)
		{
			return this.loginDAO.getEmployeeByLogin(username, password);
		}

		public virtual void setEmployeeLogin(Employee employee, string username, string password)
		{
			try
			{
				this.loginDAO.setEmployeeLogin(employee, username, password);
			}
			catch (LoginException e)
			{
				log.warn(e.Message);
			}
		}

		public virtual IList<string> AllUserNames
		{
			get
			{
				return this.loginDAO.getAllUsernames();
			}
		}

		public virtual IList<int> AllLoginOwners
		{
			get
			{
				return this.loginDAO.getAllLoginOwners();
			}
		}

		public virtual void updateLogin(Employee employee, LoginField field, string newVal)
		{
			try
			{
				this.loginDAO.updateEmployeeLogin(employee, field, newVal);
			}
			catch (LoginException e)
			{
				Console.WriteLine(e.Message);
				log.warn(e.Message);
			}
		}

		public virtual void deleteEmployeeLogin(Employee employee)
		{
			this.loginDAO.deleteEmployeeLogin(employee);
		}
	<<<<<<< HEAD public virtual string getUserName(Employee employee)
	{
			return this.loginDAO.getUserName(employee);
	}
	======= >>>>(int)((uint) >> ed8a34de6d63eed36f000f5f175bbaa344e6102f)

	}

}