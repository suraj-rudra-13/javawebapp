﻿namespace com.revature.Database
{
	public interface RecieptsDAOInterface
	{

	}

}