﻿using System.Collections.Generic;

namespace com.revature.Database
{
	using EmployeeException = com.revature.exceptions.EmployeeException;
	using Employee = com.revature.model.Employee;
	using Position = com.revature.model.Position;

	public interface EmployeeDAOInterface
	{

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in C#:
//ORIGINAL LINE: public void createEmployee(com.revature.model.Employee employee) throws com.revature.exceptions.EmployeeException;
		void createEmployee(Employee employee);
		IList<string> EmployeeIds {get;}
		Employee getEmployeeById(string employeeId); //lol JavaScript reference
		Employee getEmployeeById(int uid);
		IList<Employee> AllEmployees {get;}
		void updateEmployee(Employee employee, EmpField field, string newVal);
		void updateEmployee(Employee employee, Position newPos);
		void deleteEmployee(Employee employee);
	}

}