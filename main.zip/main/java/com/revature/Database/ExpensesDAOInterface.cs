﻿using System.Collections.Generic;

namespace com.revature.Database
{

	using Approval = com.revature.model.Approval;
	using Employee = com.revature.model.Employee;
	using Expense = com.revature.model.Expense;

	public interface ExpensesDAOInterface
	{

		void submitExpense(Expense expense);
		Expense getExpense(Employee employee, Expense expense);
		IList<Expense> getAllRequestorsExpenses(Employee employee);
		IList<Expense> AllExpenses {get;}
		void resolveExpense(int eid, Approval approval, string approvingManager);
		void deleteExpense(Expense expense);
	}

}