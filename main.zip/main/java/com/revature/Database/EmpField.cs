﻿using System.Collections.Generic;

namespace com.revature.Database
{
	/// <summary>
	/// Enumerated values for columns in database
	/// @author jonathankuhl
	/// 
	/// </summary>
	public sealed class EmpField
	{
		public static readonly EmpField FNAME = new EmpField("FNAME", InnerEnum.FNAME, "fname");
		public static readonly EmpField LNAME = new EmpField("LNAME", InnerEnum.LNAME, "lname");
		public static readonly EmpField POSITION = new EmpField("POSITION", InnerEnum.POSITION, "position");
		public static readonly EmpField STREET = new EmpField("STREET", InnerEnum.STREET, "street");
		public static readonly EmpField CITY = new EmpField("CITY", InnerEnum.CITY, "city");
		public static readonly EmpField STATE = new EmpField("STATE", InnerEnum.STATE, "state");
		public static readonly EmpField ZIP = new EmpField("ZIP", InnerEnum.ZIP, "zip");
		public static readonly EmpField PHONE = new EmpField("PHONE", InnerEnum.PHONE, "phone");
		public static readonly EmpField EMAIL = new EmpField("EMAIL", InnerEnum.EMAIL, "email");

		private static readonly List<EmpField> valueList = new List<EmpField>();

		static EmpField()
		{
			valueList.Add(FNAME);
			valueList.Add(LNAME);
			valueList.Add(POSITION);
			valueList.Add(STREET);
			valueList.Add(CITY);
			valueList.Add(STATE);
			valueList.Add(ZIP);
			valueList.Add(PHONE);
			valueList.Add(EMAIL);
		}

		public enum InnerEnum
		{
			FNAME,
			LNAME,
			POSITION,
			STREET,
			CITY,
			STATE,
			ZIP,
			PHONE,
			EMAIL
		}

		public readonly InnerEnum innerEnumValue;
		private readonly string nameValue;
		private readonly int ordinalValue;
		private static int nextOrdinal = 0;

		private string field;

		internal EmpField(string name, InnerEnum innerEnum, string field)
		{
			this.field = field;

			nameValue = name;
			ordinalValue = nextOrdinal++;
			innerEnumValue = innerEnum;
		}

		public string Field
		{
			get
			{
				return this.field;
			}
		}

		public static EmpField[] values()
		{
			return valueList.ToArray();
		}

		public int ordinal()
		{
			return ordinalValue;
		}

		public override string ToString()
		{
			return nameValue;
		}

		public static EmpField valueOf(string name)
		{
			foreach (EmpField enumInstance in EmpField.valueList)
			{
				if (enumInstance.nameValue == name)
				{
					return enumInstance;
				}
			}
			throw new System.ArgumentException(name);
		}
	}

}