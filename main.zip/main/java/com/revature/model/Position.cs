﻿using System;
using System.Collections.Generic;

namespace com.revature.model
{
	public sealed class Position
	{
		public static readonly Position MANAGER = new Position("MANAGER", InnerEnum.MANAGER, "Regional Manager");
		public static readonly Position ASSISTANT = new Position("ASSISTANT", InnerEnum.ASSISTANT, "Assistant To The Regional Manager");
		public static readonly Position SALES = new Position("SALES", InnerEnum.SALES, "Sales");
		public static readonly Position RECEPTION = new Position("RECEPTION", InnerEnum.RECEPTION, "Reception");
		public static readonly Position ACCOUNTING = new Position("ACCOUNTING", InnerEnum.ACCOUNTING, "Accounting");
		public static readonly Position HR = new Position("HR", InnerEnum.HR, "Human Resources");
		public static readonly Position QA = new Position("QA", InnerEnum.QA, "Quality Assurance");
		public static readonly Position CS = new Position("CS", InnerEnum.CS, "Customer Service");

		private static readonly List<Position> valueList = new List<Position>();

		static Position()
		{
			valueList.Add(MANAGER);
			valueList.Add(ASSISTANT);
			valueList.Add(SALES);
			valueList.Add(RECEPTION);
			valueList.Add(ACCOUNTING);
			valueList.Add(HR);
			valueList.Add(QA);
			valueList.Add(CS);
		}

		public enum InnerEnum
		{
			MANAGER,
			ASSISTANT,
			SALES,
			RECEPTION,
			ACCOUNTING,
			HR,
			QA,
			CS
		}

		public readonly InnerEnum innerEnumValue;
		private readonly string nameValue;
		private readonly int ordinalValue;
		private static int nextOrdinal = 0;

		private string position;

		internal Position(string name, InnerEnum innerEnum, string position)
		{
			this.position = position;

			nameValue = name;
			ordinalValue = nextOrdinal++;
			innerEnumValue = innerEnum;
		}

		/// <summary>
		/// Allows me to get a string value to send to DB </summary>
		/// <returns> string value of enum </returns>
		public string Position
		{
			get
			{
				return this.position;
			}
		}

		/// <summary>
		/// Allows me to fetch Enum value to retrieve from DB </summary>
		/// <param name="string"> from the DB </param>
		/// <returns> enum value </returns>
		public static Position fromString(string @string)
		{
			foreach (Position pos in Position.values())
			{
				if (pos.Position.Equals(@string, StringComparison.OrdinalIgnoreCase))
				{
					return pos;
				}
			}
			return null;
		}

		public static Position[] values()
		{
			return valueList.ToArray();
		}

		public int ordinal()
		{
			return ordinalValue;
		}

		public override string ToString()
		{
			return nameValue;
		}

		public static Position valueOf(string name)
		{
			foreach (Position enumInstance in Position.valueList)
			{
				if (enumInstance.nameValue == name)
				{
					return enumInstance;
				}
			}
			throw new System.ArgumentException(name);
		}
	}

}