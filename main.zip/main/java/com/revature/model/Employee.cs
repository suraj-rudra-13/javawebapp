﻿//====================================================================================================
//The Free Edition of Java to C# Converter limits conversion output to 100 lines per snippet.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-java-to-csharp.html
//====================================================================================================

namespace com.revature.model
{
	public class Employee
	{

		private int uid;
		private string fname;
		private string lname;
		private string employeeId;
		private Position position;
		private string street;
		private string city;
		private string state;
		private string zip;
		private string phone;
		private string email;

		private bool isManager;

		/// 
		/// <param name="uid"> </param>
		/// <param name="fname"> </param>
		/// <param name="lname"> </param>
		/// <param name="employeeId"> </param>
		/// <param name="position"> </param>
		/// <param name="street"> </param>
		/// <param name="city"> </param>
		/// <param name="state"> </param>
		/// <param name="zip"> </param>
		/// <param name="phone"> </param>
		/// <param name="email"> </param>
		/// <param name="isManager"> </param>
		public Employee(int uid, string fname, string lname, string employeeId, Position position, string street, string city, string state, string zip, string phone, string email, int isManager) : base()
		{
			this.uid = uid;
			this.fname = fname;
			this.lname = lname;
			this.employeeId = employeeId;
			this.position = position;
			this.street = street;
			this.city = city;
			this.state = state;
			this.zip = zip;
			this.phone = phone;
			this.email = email;
			this.isManager = isManager == 1; //because Oracle is teh dumz and doesn't support Boolean
		}

		public virtual string Fname
		{
			get
			{
				return fname;
			}
			set
			{
				this.fname = value;
			}
		}


		public virtual string Lname
		{
			get
			{
				return lname;
			}
			set
			{
				this.lname = value;
			}
		}


		public virtual string EmployeeId
		{
			get
			{
				return employeeId;
			}
			set
			{
				this.employeeId = value;
			}
		}


		public virtual Position Position
		{
			get
			{
				return position;
			}
			set
			{
				this.position = value;
			}
		}


		public virtual string Street
		{
			get
			{
				return street;
			}
			set
			{
				this.street = value;
			}
		}


		public virtual string City
		{
			get
			{
				return city;
			}
			set
			{
				this.city = value;
			}
		}


		public virtual string State
		{
			get
			{
				return state;
			}
			set
			{
				this.state = value;
			}
		}


		public virtual string Zip
		{
			get
			{
				return zip;
			}
			set
			{
				this.zip = value;
			}
		}


		public virtual string Phone
		{
			get
			{
				return phone;
			}
			set
			{
				this.phone = value;
			}
		}


		public virtual string Email
		{
			get
			{
				return email;
			}
			set
			{
				this.email = value;
			}
		}


		public virtual int Uid
		{
			get
			{
				return uid;
			}
		}

		public virtual bool Manager
		{
			get
			{
				return isManager;
			}
		}

		public override string ToString()
		{
			return "Employee [uid=" + uid + ", fname=" + fname + ", lname=" + lname + ", employeeId=" + employeeId + ", position=" + position.getPosition() + ", street=" + street + ", city=" + city + ", state=" + state + ", zip=" + zip + ", phone=" + phone + ", email=" + email + ", isManager=" + isManager + "]";
		}
	<<<<<<< HEAD public override int GetHashCode()
	{
			const int prime = 31;
			int result = 1;

//====================================================================================================
//End of the allowed output for the Free Edition of Java to C# Converter.

//To purchase the Premium Edition, visit our website:
//https://www.tangiblesoftwaresolutions.com/order/order-java-to-csharp.html
//====================================================================================================