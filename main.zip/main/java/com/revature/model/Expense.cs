﻿namespace com.revature.model
{
	public class Expense
	{

		private int eid;
		private string provider;
		private string date;
		private double amount;
		private string reason;
		private Approval approval; //1 approved, 2 pending, 3 denied
		private string approvingManager;
		private Employee owner;

		public Expense(int eid, string provider, string date, double amount, string reason, Approval approval, string approvingManager, Employee owner) : base()
		{
			this.eid = eid;
			this.provider = provider;
			this.date = date;
			this.amount = amount;
			this.reason = reason;
			this.approval = approval;
			this.approvingManager = approvingManager;
			this.owner = owner;
		}

		public virtual string Provider
		{
			get
			{
				return provider;
			}
			set
			{
				this.provider = value;
			}
		}


		public virtual string Date
		{
			get
			{
				return date;
			}
			set
			{
				this.date = value;
			}
		}


		public virtual string Reason
		{
			get
			{
				return reason;
			}
			set
			{
				this.reason = value;
			}
		}


		public virtual Approval Approval
		{
			get
			{
				return approval;
			}
			set
			{
				this.approval = value;
			}
		}


		public virtual string ApprovingManager
		{
			get
			{
				return approvingManager;
			}
			set
			{
				string approvingManager = value.getFname() + " " + value.getLname();
				this.approvingManager = approvingManager;
			}
		}


		public virtual Employee Owner
		{
			get
			{
				return owner;
			}
			set
			{
				this.owner = value;
			}
		}


		public virtual int Eid
		{
			get
			{
				return eid;
			}
		}

		public virtual double Amount
		{
			get
			{
				return amount;
			}
			set
			{
				this.amount = value;
			}
		}


		public virtual bool Approved
		{
			get
			{
				return this.Approval.Equals(Approval.APPROVED);
			}
		}

		public virtual bool Pending
		{
			get
			{
				return this.Approval.Equals(Approval.PENDING);
			}
		}

		public virtual bool Denied
		{
			get
			{
				return this.Approval.Equals(Approval.DENIED);
			}
		}

		public override string ToString()
		{
			return "Expense [eid=" + eid + ", provider=" + provider + ", date=" + date + ", amount=" + amount + ", reason=" + reason + ", approval=" + approval + ", approvingManager=" + approvingManager + ", owner=" + owner + "]";
		}


	}

}