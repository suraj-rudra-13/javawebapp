﻿using System.Collections.Generic;

namespace com.revature.model
{
	public sealed class Approval
	{
		public static readonly Approval APPROVED = new Approval("APPROVED", InnerEnum.APPROVED, 1);
		public static readonly Approval PENDING = new Approval("PENDING", InnerEnum.PENDING, 2);
		public static readonly Approval DENIED = new Approval("DENIED", InnerEnum.DENIED, 3);

		private static readonly List<Approval> valueList = new List<Approval>();

		static Approval()
		{
			valueList.Add(APPROVED);
			valueList.Add(PENDING);
			valueList.Add(DENIED);
		}

		public enum InnerEnum
		{
			APPROVED,
			PENDING,
			DENIED
		}

		public readonly InnerEnum innerEnumValue;
		private readonly string nameValue;
		private readonly int ordinalValue;
		private static int nextOrdinal = 0;

		private int approval;
		internal Approval(string name, InnerEnum innerEnum, int approval)
		{
			this.approval = approval;

			nameValue = name;
			ordinalValue = nextOrdinal++;
			innerEnumValue = innerEnum;
		}

		public int Approval
		{
			get
			{
				return this.approval;
			}
		}

		public static Approval getApprovalLevel(int level)
		{
			foreach (Approval app in Approval.values())
			{
				if (app.Approval == level)
				{
					return app;
				}
			}
			return null;
		}

		public static Approval[] values()
		{
			return valueList.ToArray();
		}

		public int ordinal()
		{
			return ordinalValue;
		}

		public override string ToString()
		{
			return nameValue;
		}

		public static Approval valueOf(string name)
		{
			foreach (Approval enumInstance in Approval.valueList)
			{
				if (enumInstance.nameValue == name)
				{
					return enumInstance;
				}
			}
			throw new System.ArgumentException(name);
		}
	}

}