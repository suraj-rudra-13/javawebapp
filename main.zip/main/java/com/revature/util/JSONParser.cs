﻿using System;
using System.Collections.Generic;

namespace com.revature.util
{

	public class JSONParser
	{

		public static IDictionary<string, string> parse(string json)
		{
			json = json.Replace('{', ' ').Replace('}',' ').Trim();

			string[] kvpairs = json.Split(",", true);
			IDictionary<string, string> kvmap = new Dictionary<string, string>();
			foreach (string kv in kvpairs)
			{
	<<<<<<< HEAD Console.WriteLine(kv);
	======= >>>>(int)((uint) >> ed8a34de6d63eed36f000f5f175bbaa344e6102f) String[] entries = kv.Split(":", true);
				string key = entries[0].replace('\"', ' ').Trim();
				string value = entries[1].replace('\"', ' ').Trim();
				kvmap[key] = value;
			}
			return kvmap;
		}

		public static IList<IDictionary<string, string>> parseArray(string json)
		{
			json = json.Replace('[', ' ').Replace(']', ' ').Trim();

			int firstBracer = 0;
			int secondBracer = 0;
			string @object;
			IList<IDictionary<string, string>> mappedJson = new List<IDictionary<string, string>>();
			do
			{
				if (firstBracer > json.Length || secondBracer > json.Length)
				{
					break;
				}
				firstBracer = json.IndexOf("{", secondBracer, StringComparison.Ordinal);
				secondBracer = json.IndexOf("}", firstBracer, StringComparison.Ordinal) + 1;
				@object = json.Substring(firstBracer, secondBracer - firstBracer);
				mappedJson.Add(parse(@object));
				firstBracer = secondBracer + 2;
			} while (firstBracer != -1);

			return mappedJson;

		}
	}

}

//Helper class added by Java to C# Converter:

//-------------------------------------------------------------------------------------------
//	Copyright © 2007 - 2022 Tangible Software Solutions, Inc.
//	This class can be used by anyone provided that the copyright notice remains intact.
//
//	This class is used to convert some aspects of the Java String class.
//-------------------------------------------------------------------------------------------
using System;
using System.Text;
using System.Text.RegularExpressions;

internal static class StringHelper
{
	//------------------------------------------------------------------------------------
	//	This method is used to replace calls to the 2-arg Java String.startsWith method.
	//------------------------------------------------------------------------------------
	public static bool StartsWith(this string self, string prefix, int toffset)
	{
		return self.IndexOf(prefix, toffset, StringComparison.Ordinal) == toffset;
	}

	//------------------------------------------------------------------------------
	//	This method is used to replace most calls to the Java String.split method.
	//------------------------------------------------------------------------------
	public static string[] Split(this string self, string regexDelimiter, bool trimTrailingEmptyStrings)
	{
		string[] splitArray = Regex.Split(self, regexDelimiter);

		if (trimTrailingEmptyStrings)
		{
			if (splitArray.Length > 1)
			{
				for (int i = splitArray.Length; i > 0; i--)
				{
					if (splitArray[i - 1].Length > 0)
					{
						if (i < splitArray.Length)
							Array.Resize(ref splitArray, i);

						break;
					}
				}
			}
		}

		return splitArray;
	}

	//-----------------------------------------------------------------------------
	//	These methods are used to replace calls to some Java String constructors.
	//-----------------------------------------------------------------------------
	public static string NewString(sbyte[] bytes)
	{
		return NewString(bytes, 0, bytes.Length);
	}
	public static string NewString(sbyte[] bytes, int index, int count)
	{
		return Encoding.UTF8.GetString((byte[])(object)bytes, index, count);
	}
	public static string NewString(sbyte[] bytes, string encoding)
	{
		return NewString(bytes, 0, bytes.Length, encoding);
	}
	public static string NewString(sbyte[] bytes, int index, int count, string encoding)
	{
		return NewString(bytes, index, count, Encoding.GetEncoding(encoding));
	}
	public static string NewString(sbyte[] bytes, Encoding encoding)
	{
		return NewString(bytes, 0, bytes.Length, encoding);
	}
	public static string NewString(sbyte[] bytes, int index, int count, Encoding encoding)
	{
		return encoding.GetString((byte[])(object)bytes, index, count);
	}

	//--------------------------------------------------------------------------------
	//	These methods are used to replace calls to the Java String.getBytes methods.
	//--------------------------------------------------------------------------------
	public static sbyte[] GetBytes(this string self)
	{
		return GetSBytesForEncoding(Encoding.UTF8, self);
	}
	public static sbyte[] GetBytes(this string self, Encoding encoding)
	{
		return GetSBytesForEncoding(encoding, self);
	}
	public static sbyte[] GetBytes(this string self, string encoding)
	{
		return GetSBytesForEncoding(Encoding.GetEncoding(encoding), self);
	}
	private static sbyte[] GetSBytesForEncoding(Encoding encoding, string s)
	{
		sbyte[] sbytes = new sbyte[encoding.GetByteCount(s)];
		encoding.GetBytes(s, 0, s.Length, (byte[])(object)sbytes, 0);
		return sbytes;
	}
}