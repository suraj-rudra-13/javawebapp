﻿using System;
using System.IO;

namespace com.revature.Connection
{

	using Logger = org.apache.log4j.Logger;

	using FrontController = com.revature.Servlets.FrontController;

	public class JDBCConnection
	{
		internal static readonly Logger log = Logger.getLogger(typeof(JDBCConnection));

		public static Connection Connection
		{
			get
			{
    
				Stream inp = null;
    
				try
				{
    
					Type.GetType("oracle.jdbc.driver.OracleDriver");
    
					Connection conn = null;
    
					string currentDir = Path.GetFullPath(".");
    
					Properties props = new Properties();
					inp = new FileStream("/Users/jonathankuhl/Documents/workspace-sts-3.9.5.RELEASE/project1/src/main/resources/project1.properties", FileMode.Open, FileAccess.Read);
					props.load(inp);
    
					string endpoint = props.getProperty("jdbc.url");
					string username = props.getProperty("jdbc.username");
					string password = props.getProperty("jdbc.password");
    
					conn = DriverManager.getConnection(endpoint, username, password);
    
					return conn;
    
				}
				catch (Exception e)
				{
					Console.WriteLine(e.ToString());
					Console.Write(e.StackTrace);
					log.error(e.Message);
				}
				finally
				{
					try
					{
						inp.Close();
					}
					catch (IOException e)
					{
						// TODO Auto-generated catch block
						Console.WriteLine(e.ToString());
						Console.Write(e.StackTrace);
					}
				}
				return null;
			}
		}

	}


}