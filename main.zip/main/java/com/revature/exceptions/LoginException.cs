﻿using System;

namespace com.revature.exceptions
{
	public class LoginException : Exception
	{

		private string message;

		public LoginException()
		{
			this.message = "Employee already has a username and password!";
		}

		public LoginException(string message)
		{
			this.message = message;
		}

		public override string Message
		{
			get
			{
				return this.message;
			}
		}


	}

}