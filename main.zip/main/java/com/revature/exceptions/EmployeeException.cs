﻿using System;

namespace com.revature.exceptions
{
	public class EmployeeException : Exception
	{

		public override string Message
		{
			get
			{
				return "Employee is already in database!";
			}
		}



	}

}